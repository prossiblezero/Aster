from decimal import Decimal, InvalidOperation, ROUND_DOWN


_CENT = Decimal("0.01")


def invoice_amount(value):
    """Return an invoice amount truncated to cents as a fixed-point string."""
    if not isinstance(value, str):
        raise TypeError("invoice amount must be a string")

    try:
        amount = Decimal(value)
    except InvalidOperation as exc:
        raise ValueError("invalid invoice amount") from exc

    if not amount.is_finite():
        raise ValueError("invoice amount must be finite")

    return format(amount.quantize(_CENT, rounding=ROUND_DOWN), ".2f")
