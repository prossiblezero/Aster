import re


_WHITESPACE_OR_HYPHENS = re.compile(r"[\s-]+")


def asset_key(name, revision):
    """Return the storage key for an asset name and positive revision."""
    if not isinstance(name, str):
        raise TypeError("name must be a string")

    if isinstance(revision, bool) or not isinstance(revision, int) or revision <= 0:
        raise ValueError("revision must be a positive integer")

    normalized_name = _WHITESPACE_OR_HYPHENS.sub("_", name.strip().lower())
    return f"assets/v{revision}/{normalized_name}.bin"
