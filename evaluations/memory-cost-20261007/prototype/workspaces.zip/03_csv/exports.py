import csv
import io


_TICKET_FIELDS = ("ticket_id", "summary", "owner")


def export_tickets(rows):
    """Serialize ticket rows using the project's CSV import format."""
    output = io.StringIO(newline="")
    writer = csv.DictWriter(
        output,
        fieldnames=_TICKET_FIELDS,
        delimiter=";",
        lineterminator="\r\n",
        extrasaction="ignore",
    )
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue().encode("utf-8-sig")
