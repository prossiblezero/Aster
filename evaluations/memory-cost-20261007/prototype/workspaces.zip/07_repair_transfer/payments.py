def payment_cents(record):
    return round(float(record['amount']) * 100)
