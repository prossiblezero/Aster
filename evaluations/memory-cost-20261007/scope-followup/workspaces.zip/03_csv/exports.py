import csv
import io


_TICKET_COLUMNS = ("ticket_id", "summary", "owner")


def export_tickets(rows):
    """Return ticket rows as the project's semicolon-delimited CSV bytes."""
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer, delimiter=";", lineterminator="\r\n")
    writer.writerow(_TICKET_COLUMNS)

    for row in rows:
        writer.writerow(row.get(column, "") for column in _TICKET_COLUMNS)

    return buffer.getvalue().encode("utf-8-sig")
