import re


def asset_key(name, revision):
    """Return the storage key for an asset name and positive revision."""
    if isinstance(revision, bool) or not isinstance(revision, int) or revision <= 0:
        raise ValueError("revision must be a positive integer")

    normalized_name = re.sub(r"[\s-]+", "_", name.strip().lower())
    return f"assets/v{revision}/{normalized_name}.bin"
