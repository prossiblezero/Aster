Asset revisions must be positive integers. Invalid revisions raise ValueError.
