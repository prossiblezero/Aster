Asset names: trim outer whitespace, lowercase, replace each run of whitespace or hyphens with one underscore. Preserve other characters.
