Asset storage keys have prefix assets/v{revision}/ and extension .bin.
