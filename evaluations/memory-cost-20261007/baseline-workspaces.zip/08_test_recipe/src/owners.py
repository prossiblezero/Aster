def normalize_owner(value):
    return '_'.join(value.lower().split())
