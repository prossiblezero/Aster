def normalize_name(value):
    return '_'.join(value.lower().split())
