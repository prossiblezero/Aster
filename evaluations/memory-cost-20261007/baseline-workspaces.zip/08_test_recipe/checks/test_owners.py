import unittest
from owners import normalize_owner
class OwnerTests(unittest.TestCase):
    def test_owner(self):
        self.assertEqual(normalize_owner('  Grace   HOPPER '), 'grace_hopper')
