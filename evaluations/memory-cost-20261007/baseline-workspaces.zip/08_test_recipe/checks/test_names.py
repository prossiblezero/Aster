import unittest
from names import normalize_name
class NameTests(unittest.TestCase):
    def test_name(self):
        self.assertEqual(normalize_name('  Ada   LOVELACE  '), 'ada_lovelace')
    def test_empty(self):
        self.assertEqual(normalize_name('   '), '')
