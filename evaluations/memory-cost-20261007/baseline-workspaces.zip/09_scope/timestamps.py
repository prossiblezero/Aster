from datetime import datetime, timezone
from zoneinfo import ZoneInfo


_TARGET_TIMEZONES = {
    "analytics": ZoneInfo("Asia/Shanghai"),
    "public_api": timezone.utc,
}
_TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M"


def format_timestamp(iso_timestamp, target):
    """Format a timezone-aware ISO timestamp for a project interface."""
    try:
        target_timezone = _TARGET_TIMEZONES[target]
    except KeyError as exc:
        raise ValueError(f"Unknown timestamp target: {target!r}") from exc

    timestamp = datetime.fromisoformat(iso_timestamp)
    if timestamp.tzinfo is None or timestamp.utcoffset() is None:
        raise ValueError("iso_timestamp must include a timezone")

    return timestamp.astimezone(target_timezone).strftime(_TIMESTAMP_FORMAT)
