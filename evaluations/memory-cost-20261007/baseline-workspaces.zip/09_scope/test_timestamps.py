import unittest

from timestamps import format_timestamp


class FormatTimestampTests(unittest.TestCase):
    def test_analytics_converts_utc_to_shanghai_and_crosses_day(self):
        self.assertEqual(
            format_timestamp("2024-01-15T16:30:00Z", "analytics"),
            "2024-01-16 00:30",
        )

    def test_public_api_converts_offset_to_utc(self):
        self.assertEqual(
            format_timestamp("2024-01-16T08:30:00+08:00", "public_api"),
            "2024-01-16 00:30",
        )

    def test_unknown_target_raises_value_error(self):
        with self.assertRaises(ValueError):
            format_timestamp("2024-01-15T16:30:00Z", "internal")

    def test_naive_timestamp_raises_value_error(self):
        with self.assertRaises(ValueError):
            format_timestamp("2024-01-15T16:30:00", "public_api")


if __name__ == "__main__":
    unittest.main()
