import csv
import io


_FIELDNAMES = ("ticket_id", "summary", "owner")


def export_tickets(rows):
    """Return ticket rows as the project's semicolon-delimited CSV bytes."""
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=";", lineterminator="\r\n")
    writer.writerow(_FIELDNAMES)

    for row in rows:
        writer.writerow(row.get(field) for field in _FIELDNAMES)

    return output.getvalue().encode("utf-8-sig")
