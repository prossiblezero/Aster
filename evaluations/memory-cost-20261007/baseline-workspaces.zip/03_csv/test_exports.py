import csv
import io
import unittest

from exports import export_tickets


class ExportTicketsTests(unittest.TestCase):
    def test_exports_project_columns_with_csv_escaping(self):
        data = export_tickets(
            [
                {
                    "ticket_id": "T-1",
                    "summary": "登录;失败\n请重试",
                    "owner": "张三",
                    "extra": "ignored",
                },
                {"ticket_id": 2, "summary": '含"引号"', "owner": None},
            ]
        )

        self.assertIsInstance(data, bytes)
        self.assertTrue(data.startswith(b"\xef\xbb\xbf"))
        rows = list(csv.reader(io.StringIO(data.decode("utf-8-sig")), delimiter=";"))
        self.assertEqual(
            rows,
            [
                ["ticket_id", "summary", "owner"],
                ["T-1", "登录;失败\n请重试", "张三"],
                ["2", '含"引号"', ""],
            ],
        )

    def test_empty_input_writes_header(self):
        self.assertEqual(
            export_tickets([]).decode("utf-8-sig"),
            "ticket_id;summary;owner\r\n",
        )


if __name__ == "__main__":
    unittest.main()
