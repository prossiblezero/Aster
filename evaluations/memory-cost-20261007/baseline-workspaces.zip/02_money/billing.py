from decimal import Decimal, InvalidOperation, ROUND_DOWN


def invoice_amount(value):
    """Format a decimal invoice amount to two places by truncating it."""
    if not isinstance(value, str):
        raise TypeError("invoice amount must be a string")
    if not value.strip():
        raise ValueError("invoice amount must not be empty")

    try:
        amount = Decimal(value)
    except InvalidOperation as exc:
        raise ValueError("invoice amount must be a decimal string") from exc

    if not amount.is_finite():
        raise ValueError("invoice amount must be finite")

    return format(amount.quantize(Decimal("0.01"), rounding=ROUND_DOWN), ".2f")
