import pytest

from billing import invoice_amount


def test_invoice_amount_truncates_and_formats_decimal_strings():
    assert invoice_amount("12") == "12.00"
    assert invoice_amount("12.349") == "12.34"
    assert invoice_amount("-12.349") == "-12.34"
    assert invoice_amount("1e2") == "100.00"


@pytest.mark.parametrize("value", ["", "abc", "NaN", "Infinity"])
def test_invoice_amount_rejects_invalid_strings(value):
    with pytest.raises(ValueError):
        invoice_amount(value)


def test_invoice_amount_requires_a_string():
    with pytest.raises(TypeError):
        invoice_amount(12)
