Project narrative summaries use French. This convention concerns prose, not string processing behavior.
