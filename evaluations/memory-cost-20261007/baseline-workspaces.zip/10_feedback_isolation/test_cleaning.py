import unittest
from cleaning import normalize_spaces
class CleaningTests(unittest.TestCase):
    def test_spaces(self):
        self.assertEqual(normalize_spaces('  one   two  '), 'one two')
