def normalize_spaces(value):
    return " ".join(value.split())
