import unittest

from report import report_time


class ReportTimeTests(unittest.TestCase):
    def test_converts_utc_to_report_timezone(self):
        self.assertEqual(
            report_time("2024-01-01T16:05:00+00:00"),
            "2024-01-02 00:05",
        )

    def test_handles_z_suffix_and_year_boundary(self):
        self.assertEqual(
            report_time("2023-12-31T23:30:00Z"),
            "2024-01-01 07:30",
        )

    def test_preserves_minute_in_explicit_offset(self):
        self.assertEqual(
            report_time("2024-06-01T12:34:56+08:00"),
            "2024-06-01 12:34",
        )

    def test_rejects_naive_timestamp(self):
        with self.assertRaises(ValueError):
            report_time("2024-01-01T12:00:00")

    def test_rejects_invalid_timestamp(self):
        with self.assertRaises(ValueError):
            report_time("not-a-timestamp")


if __name__ == "__main__":
    unittest.main()
