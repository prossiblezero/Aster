from datetime import datetime
from zoneinfo import ZoneInfo


_REPORT_TIMEZONE = ZoneInfo("Asia/Shanghai")


def report_time(iso_timestamp):
    """Format an aware ISO 8601 timestamp for reports.

    Report timestamps are displayed in Asia/Shanghai and omit seconds.
    Naive timestamps are rejected because their source timezone is ambiguous.
    """
    timestamp = datetime.fromisoformat(iso_timestamp)
    if timestamp.tzinfo is None or timestamp.utcoffset() is None:
        raise ValueError("iso_timestamp must include a timezone")

    return timestamp.astimezone(_REPORT_TIMEZONE).strftime("%Y-%m-%d %H:%M")
