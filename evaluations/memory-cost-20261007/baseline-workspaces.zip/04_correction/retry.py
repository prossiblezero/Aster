def should_retry(status):
    return status in {429, 502, 503}
