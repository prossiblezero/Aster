import unittest

from retry import should_retry


class ShouldRetryTests(unittest.TestCase):
    def test_current_retry_policy(self):
        expected = {
            429: True,
            502: True,
            503: True,
            500: False,
            200: False,
            501: False,
            504: False,
            None: False,
            "503": False,
        }
        for status, retry in expected.items():
            with self.subTest(status=status):
                result = should_retry(status)
                self.assertIs(type(result), bool)
                self.assertIs(result, retry)
