import unittest

from refunds import refund_cents


class RefundTests(unittest.TestCase):
    def test_sums_payment_record_formats(self):
        records = [
            {'amount_minor': 123, 'amount': '9.99'},
            {'amount': '1.005'},
            {'amount_minor': -50},
        ]
        self.assertEqual(refund_cents(records), 174)

    def test_empty_records(self):
        self.assertEqual(refund_cents([]), 0)

    def test_negative_decimal_rounding(self):
        self.assertEqual(refund_cents([{'amount': '-1.005'}]), -101)


if __name__ == '__main__':
    unittest.main()
