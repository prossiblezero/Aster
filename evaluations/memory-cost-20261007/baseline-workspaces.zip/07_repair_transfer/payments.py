from decimal import Decimal, ROUND_HALF_UP


def payment_cents(record):
    if 'amount_minor' in record:
        return record['amount_minor']

    amount = Decimal(str(record['amount'])) * 100
    return int(amount.quantize(Decimal('1'), rounding=ROUND_HALF_UP))
