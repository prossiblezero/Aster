import unittest
from payments import payment_cents
class PaymentTests(unittest.TestCase):
    def test_legacy_precedence(self):
        self.assertEqual(payment_cents({'amount_minor': 123, 'amount': '9.99'}), 123)
    def test_decimal_rounding(self):
        self.assertEqual(payment_cents({'amount': '1.005'}), 101)
    def test_negative(self):
        self.assertEqual(payment_cents({'amount': '-1.005'}), -101)
