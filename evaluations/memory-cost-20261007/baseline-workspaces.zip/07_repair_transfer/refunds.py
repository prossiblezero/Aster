from payments import payment_cents


def refund_cents(records):
    return sum(payment_cents(record) for record in records)
