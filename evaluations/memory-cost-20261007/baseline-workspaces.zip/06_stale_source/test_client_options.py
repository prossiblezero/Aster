import unittest

from client import client_options


class ClientOptionsTest(unittest.TestCase):
    def test_returns_project_client_configuration(self):
        options = client_options()
        self.assertIs(type(options), dict)
        self.assertEqual(options, {"timeout": 13, "retries": 0})

    def test_returns_a_fresh_configuration(self):
        options = client_options()
        options["timeout"] = 99
        self.assertEqual(client_options(), {"timeout": 13, "retries": 0})


if __name__ == "__main__":
    unittest.main()
