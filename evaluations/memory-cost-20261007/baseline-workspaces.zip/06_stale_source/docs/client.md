Client timeout is 13 seconds; retry count is 0. client_options returns a dict with timeout and retries.
