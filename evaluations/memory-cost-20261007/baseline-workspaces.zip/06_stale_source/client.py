def client_options():
    return {"timeout": 13, "retries": 0}
